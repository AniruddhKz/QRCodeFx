/**
 * 
 */
/**
 * 
 */
module QRCodeFx {
}