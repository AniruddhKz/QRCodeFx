package com.aniruddha;

public class QRCodeFxDemo {

	AbstractJavaFxApplicationSupport{
		@Override
		public void start(Stage primaaryStage) {
			Group root= new Group();
			VCard vCard=new VCard("Aniruddha ");
			
			QRCodeImage qrCodeImage= QRCode.from(vCard).withSize(250, 250).image();
			javafx.scene.image.Image image= new javafx.scene.image.Image(qrCodeImage.stream(),250, 250, true, true);
			javafx.scene.image.ImageView imageView= new javafx.scene.image.ImageView(image);
			Scene scene=new scene(new StackPane(root), 300, 300, Color.WHITE);
			
			primaryStage.setTitle("QRCodefx");
			primaryStage.setScene(scene);
			primaryStage.show();
		}
		
		
	
	public static void main(String[] args) {
	
		launch(QRCodeFxDemo.class, SplashScreen.class, args);
		

	}

}
